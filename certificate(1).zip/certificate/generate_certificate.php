<?php
// Database connection
$servername = "localhost";
$username = "u336359557_cert";
$password = "Future123@@@";
$dbname = "u336359557_cert";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

require('fpdf/fpdf.php');
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'vendor/autoload.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];

    // Check if the user is in the attendees list
    $sql = "SELECT * FROM attendees WHERE name = ? AND email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $name, $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 0) {
        echo '<div class="message error">You are not part of the attendees. Please check with the event coordinator.</div>';
    } else {
        // Check if the certificate has already been sent
        $sql = "SELECT * FROM certificate_requests WHERE name = ? AND email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $name, $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            echo '<div class="message error">Certificate for ' . $name . ' has already been sent to ' . $email . '.</div>';
        } else {
            // Create PDF certificate
            class PDF extends FPDF {
                function Header() {
                    // Add background image for the certificate
                     $this->Image('certificate_background.jpg', 0, 0, 297, 210); 
                }
            }

            $pdf = new PDF();
            $pdf->AddPage('L');

            // // Customize the certificate content
            // $pdf->SetFont('Arial', 'B', 35);
            // $pdf->SetTextColor(33, 150, 243);
            // $pdf->Cell(0, 50, 'Certificate of Achievement', 0, 1, 'C');

           // Customize the certificate content
$pdf->Ln(100); // Adjust this value as needed for proper positioning
$pdf->SetFont('Arial', 'B', 35);
$pdf->SetTextColor(0, 0, 0);
$pdf->Cell(0, 30, $name, 0, 1, 'C');
            // $pdf->SetFont('Arial', '', 18);
            // $pdf->Cell(0, 20, 'Has successfully completed the Bootcamp', 0, 1, 'C');
            // $pdf->Ln(10);
            // $pdf->Cell(0, 20, 'Issued on ' . date("F j, Y"), 0, 1, 'C');

            // $pdf->Image('signature.png', 150, 240, 40, 40);
            // $pdf->SetFont('Arial', 'I', 12);
            // $pdf->Cell(0, 10, 'John Doe, Bootcamp Coordinator', 0, 1, 'R');

            // Save the certificate as a PDF file
            $file_name = 'certificate_' . time() . '.pdf';
            $pdf->Output('F', $file_name);

            // Send the certificate via email
            $mail = new PHPMailer(true);
            try {
                $mail->SMTPDebug = 0;
                $mail->isSMTP();
                $mail->Host = 'smtp.hostinger.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'info@digitalcrafte.io';
                $mail->Password = 'Future123@@@';
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;

                // Recipients
                $mail->setFrom('info@digitalcrafte.io', 'Bootcamp Team');
                $mail->addAddress($email);

                // Attach the certificate
                $mail->addAttachment($file_name);

                // Email content
                $mail->isHTML(true);
                $mail->Subject = 'Your Bootcamp Certificate';
                $mail->Body = "<h3>Dear $name,</h3><p>Congratulations on completing the bootcamp!</p><p>Your certificate is attached.</p><p>Best regards,<br>TeQFlow</p>";

                $mail->send();

                // Store user in the certificate_requests table after successful email
                $sql = "INSERT INTO certificate_requests (name, email) VALUES (?, ?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ss", $name, $email);
                $stmt->execute();

                // Redirect to success page
                header('Location: success.php');
                exit();
            } catch (Exception $e) {
                // Redirect to error page with error message
                header('Location: error.php');
                exit();
            }

            // Delete the PDF after sending
            unlink($file_name);
        }
    }
}

$conn->close();
?>
