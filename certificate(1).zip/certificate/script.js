document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('certificateForm');
    const message = document.getElementById('message');

    form.addEventListener('submit', function (e) {
        e.preventDefault();

        message.textContent = 'Processing...';

        const formData = new FormData(form);

        fetch('generate_certificate.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.text())
        .then(data => {
            message.textContent = data;
            form.reset();
        })
        .catch(error => {
            console.error('Error:', error);
            message.textContent = 'An error occurred. Please try again.';
        });
    });
});
